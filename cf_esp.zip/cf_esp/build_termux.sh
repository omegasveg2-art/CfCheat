#!/data/data/com.termux/files/usr/bin/sh
# Build ON the phone in Termux (native clang = bionic). Needs network for the AOSP headers (once).
# usage: sh build_termux.sh [12|13|14]   (= device Android version; getprop ro.build.version.release)
# NOT verified by the author -- AOSP private headers are version specific; if the compile errors in gui/*, pick the right branch.
set -e
VER=${1:-13}
cd "$(dirname "$0")"
pkg install -y clang git binutils >/dev/null
H=third_party/aosp
if [ ! -d $H/frameworks_native ]; then
  mkdir -p $H
  for r in platform_frameworks_native platform_system_core platform_hardware_libhardware; do
    git clone --depth 1 -b android$VER-release https://github.com/aosp-mirror/$r.git $H/${r#platform_}
  done
fi
FN=$H/frameworks_native; SC=$H/system_core
INC="-I$FN/libs/gui/include -I$FN/libs/ui/include -I$FN/libs/binder/include -I$FN/libs/nativewindow/include -I$FN/libs/arect/include \
 -I$FN/libs/math/include -I$FN/libs/nativebase/include -I$FN/libs/ftl/include -I$FN/libs/renderengine/include -I$FN/libs/graphicsenv/include \
 -I$FN/include -I$SC/libutils/include -I$SC/libcutils/include -I$SC/liblog/include -I$SC/libsystem/include -I$SC/libprocessgroup/include \
 -I$H/hardware_libhardware/include -Ithird_party/imgui -Ithird_party"
SRC="src/main.cpp src/mem.cpp src/il2cpp.cpp src/game.cpp src/esp.cpp src/overlay_sf.cpp third_party/imgui/imgui*.cpp"
clang++ -std=c++20 -O2 -fno-exceptions -fPIE -DAOSP_VER=$VER -DIMGUI_IMPL_OPENGL_ES3 $INC $SRC -o cf_esp \
  -L/system/lib64 -lgui -lui -lbinder -lutils -lcutils -llog -lEGL -lGLESv3 -landroid -static-libstdc++
echo built: cf_esp
sh pack.sh cf_esp cf_esp.sh
