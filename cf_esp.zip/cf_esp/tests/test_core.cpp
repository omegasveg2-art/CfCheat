// host test: builds a fake CounterFlame process image from offsets.h and runs the real Game/Il2 code on it.
// g++ -std=c++17 -I../src test_core.cpp ../src/il2cpp.cpp ../src/game.cpp ../src/mem.cpp -o test_core && ./test_core
#include "../src/game.h"
#include <cassert>
#include <cstdio>
#include <cstring>
#include <map>

struct FakeMem : IMem {
    struct Chunk { std::vector<uint8_t> d; Region r; };
    std::map<uint64_t, Chunk> c;
    void alloc(uint64_t a, size_t n, bool w = true, const char* path = "") {
        Chunk ch; ch.d.assign(n, 0);
        ch.r.start = a; ch.r.end = a + n; ch.r.r = true; ch.r.w = w; ch.r.path = path;
        c[a] = std::move(ch);
    }
    uint8_t* at(uint64_t a, size_t n) {
        a = untag(a);
        auto it = c.upper_bound(a);
        if (it == c.begin()) return nullptr;
        --it;
        if (a < it->first || a + n > it->first + it->second.d.size()) return nullptr;
        return &it->second.d[a - it->first];
    }
    bool read(uint64_t a, void* out, size_t n) override {
        uint8_t* p = at(a, n);
        if (!p) { memset(out, 0, n); return false; }
        memcpy(out, p, n); return true;
    }
    std::vector<Region> regions() override { std::vector<Region> v; for (auto& k : c) v.push_back(k.second.r); return v; }
    template <class T> void w(uint64_t a, T v) { uint8_t* p = at(a, sizeof(T)); assert(p); memcpy(p, &v, sizeof(T)); }
    void wstr(uint64_t a, const char* s) { uint8_t* p = at(a, strlen(s) + 1); assert(p); memcpy(p, s, strlen(s) + 1); }
};

static int fails = 0;
#define CHECK(x) do { if (!(x)) { printf("FAIL %s:%d  %s\n", __FILE__, __LINE__, #x); fails++; } } while (0)

int main() {
    // ---- w2s sanity (left-handed, forward +Z, right +X)
    {
        Cam c; c.pos = {0, 0, 0}; c.fwd = {0, 0, 1}; c.fovY = 90;
        float x, y;
        CHECK(w2s(c, {0, 0, 10}, 1920, 1080, x, y) && fabsf(x - 960) < 1e-3 && fabsf(y - 540) < 1e-3);
        CHECK(w2s(c, {10, 0, 10}, 1920, 1080, x, y) && x > 960);              // +X is right
        CHECK(w2s(c, {0, 10, 10}, 1920, 1080, x, y) && fabsf(y - 0) < 1e-2);  // fov 90 vertical: +10 at z=10 is top edge
        CHECK(!w2s(c, {0, 0, -5}, 1920, 1080, x, y));
        c.fwd = {1, 0, 0};                                                    // turned right: old +Z point is now on the left
        CHECK(w2s(c, {10, 0, 5}, 1920, 1080, x, y) && x > 960 == false ? true : (w2s(c, {10, 0, -5}, 1920, 1080, x, y) && x < 960));
    }

    // ---- fake process
    FakeMem m;
    const uint64_t BASE = 0x7100000000ull, KL = 0x7200000000ull, META = 0x7300000000ull, HEAP = 0x7400000000ull;
    m.alloc(BASE + 0x39C0000, 0x10000, true, "/data/app/x/lib/arm64/libil2cpp.so");
    m.alloc(KL, 0x4000);
    m.alloc(META, 0x1000, false, "/data/app/x/assets/bin/Data/Managed/Metadata/global-metadata.dat");
    m.alloc(HEAP, 0x20000);

    // metadata strings
    uint64_t sCull = META + 0x10, sFps = META + 0x40, sLife = META + 0x70, sEmpty = META + 0x100, sNsGame = META + 0x110, sNsLife = META + 0x140;
    m.wstr(sCull, "PlayerCulling"); m.wstr(sFps, "PlayerFPSCamera"); m.wstr(sLife, "LifeState");
    m.wstr(sEmpty, ""); m.wstr(sNsGame, "ScarletWork.Game"); m.wstr(sNsLife, "ScarletWork.Game.Life");
    // preceding NULs are already there (zero-init) -> "\0Name\0" matches

    auto mkclass = [&](uint64_t k, uint64_t name, uint64_t ns, uint64_t statics) {
        m.w<uint64_t>(k + 0x10, name); m.w<uint64_t>(k + 0x18, ns); m.w<uint64_t>(k + 0x78, k); m.w<uint64_t>(k + 0xB8, statics);
    };
    uint64_t kCull = KL + 0x000, kFps = KL + 0x400, kLife = KL + 0x800;
    uint64_t stCull = HEAP + 0x100, stFps = HEAP + 0x200;
    mkclass(kCull, sCull, sEmpty, stCull);
    mkclass(kFps, sFps, sNsGame, stFps);
    mkclass(kLife, sLife, sNsLife, 0);
    // TypeInfo slots (cull with a TAGGED pointer like scudo would produce, life slot left empty -> scan path)
    m.w<uint64_t>(BASE + off::PlayerCulling::cls.typeinfo_rva, kCull | (0xb4ull << 56));
    m.w<uint64_t>(BASE + off::PlayerFPSCamera::cls.typeinfo_rva, kFps);

    // camera
    m.w<uint8_t>(stCull + off::PlayerCulling::s__hasCamera, 1);
    m.w<Vec3>(stCull + off::PlayerCulling::s__cameraPosition, {0, 1.6f, 0});
    m.w<Vec3>(stCull + off::PlayerCulling::s__cameraForward, {0, 0, 1});
    uint64_t fpsLocal = HEAP + 0x300;
    m.w<uint64_t>(stFps + off::PlayerFPSCamera::s_Local, fpsLocal);
    m.w<float>(fpsLocal + off::PlayerFPSCamera::BaseFieldOfView, 75.f);

    // players: List<PlayerCulling> at HEAP+0x1000, array at +0x1100
    uint64_t lst = HEAP + 0x1000, arr = HEAP + 0x1100;
    m.w<uint64_t>(stCull + off::PlayerCulling::s_Instances, lst);
    m.w<uint64_t>(lst + il2::LIST_ITEMS, arr | (0xb4ull << 56)); m.w<uint32_t>(lst + il2::LIST_SIZE, 3);
    m.w<uint32_t>(arr + il2::ARR_LEN, 8);
    struct P { int actor; bool mine; bool death; Vec3 pos; const char* nick; int hp; uint8_t team; bool alive; } ps[3] = {
        {1, true,  false, {1, 0, 1},  "me",    100, 1, true},
        {2, false, false, {0, 0, 20}, "Enemy", 73,  2, true},
        {3, false, true,  {5, 0, 9},  "Dead",  0,   1, false},
    };
    for (int i = 0; i < 3; i++) {
        uint64_t base = HEAP + 0x2000 + i * 0x800;
        uint64_t cull = base, ctrl = base + 0x100, net = base + 0x200, view = base + 0x400, pl = base + 0x500, nick = base + 0x600;
        m.w<uint64_t>(arr + il2::ARR_DATA + i * 8, cull);
        m.w<uint64_t>(cull + off::PlayerCulling::_controller, ctrl);
        m.w<uint64_t>(cull + off::PlayerCulling::_network, net);
        m.w<uint64_t>(ctrl + off::PlayerController::_view, view);
        m.w<uint64_t>(ctrl + off::PlayerController::_player, pl);
        m.w<uint8_t>(ctrl + off::PlayerController::_isDeath, ps[i].death);
        m.w<uint8_t>(view + off::PhotonView::IsMine, ps[i].mine);
        m.w<uint32_t>(view + off::PhotonView::ownerActorNr, ps[i].actor);
        m.w<Vec3>(net + off::PlayerNetwork::networkPosition, ps[i].pos);
        m.w<uint8_t>(net + off::PlayerNetwork::_appliedBools, i == 1 ? 2 : 0);   // enemy crouching
        m.w<uint64_t>(pl + off::Player::nickName, nick);
        size_t L = strlen(ps[i].nick);
        m.w<uint32_t>(nick + il2::STR_LEN, (uint32_t)L);
        for (size_t k = 0; k < L; k++) m.w<uint16_t>(nick + il2::STR_CHARS + k * 2, (uint16_t)ps[i].nick[k]);
    }
    // LifeState instance + entries
    uint64_t life = HEAP + 0x8000, llist = HEAP + 0x8100, larr = HEAP + 0x8200;
    m.w<uint64_t>(life, kLife);
    m.w<uint64_t>(life + off::LifeState::_entries, llist);
    m.w<uint64_t>(llist + il2::LIST_ITEMS, larr); m.w<uint32_t>(llist + il2::LIST_SIZE, 3);
    m.w<uint32_t>(larr + il2::ARR_LEN, 4);
    for (int i = 0; i < 3; i++) {
        uint64_t e = larr + il2::ARR_DATA + i * off::LifeEntrySize;
        m.w<int32_t>(e + off::LifeEntry::Actor, ps[i].actor);
        m.w<int32_t>(e + off::LifeEntry::Health, ps[i].hp);
        m.w<uint8_t>(e + off::LifeEntry::Alive, ps[i].alive);
        m.w<uint8_t>(e + off::LifeEntry::Team, ps[i].team);
    }
    // decoy: an object-looking word equal to kLife with an empty entries list must be rejected
    m.w<uint64_t>(HEAP + 0x9000, kLife);

    Game g(m, BASE);
    CHECK(g.resolve());
    Snapshot s;
    CHECK(g.update(s));
    CHECK(s.valid && s.lifeOk && s.haveLocal);
    CHECK(s.localActor == 1 && s.localTeam == 1);
    CHECK(fabsf(s.cam.fovY - 75.f) < 1e-4);
    CHECK(s.players.size() == 3);
    if (s.players.size() == 3) {
        CHECK(s.players[1].actor == 2 && s.players[1].hp == 73 && s.players[1].team == 2 && s.players[1].crouch);
        CHECK(std::string(s.players[1].name) == "Enemy");
        CHECK(s.players[2].dead);
        float x, y;
        CHECK(w2s(s.cam, s.players[1].pos + Vec3{0, 1.7f, 0}, 2400, 1080, x, y));
        printf("enemy head on screen: %.1f %.1f\n", x, y);
    }
    printf(fails ? "%d FAILED\n" : "all ok\n", fails);
    return fails != 0;
}
