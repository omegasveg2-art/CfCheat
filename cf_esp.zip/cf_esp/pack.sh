#!/bin/sh
# usage: ./pack.sh <built cf_esp binary> [out.sh]   -> single self-extracting script for MT Manager ("run as root")
set -e
BIN="$1"; OUT="${2:-cf_esp.sh}"
[ -f "$BIN" ] || { echo "usage: $0 <binary> [out.sh]"; exit 1; }
cat > "$OUT" <<'HDR'
#!/system/bin/sh
# CounterFlame ESP - self-extracting. Run as root. Args are passed to the binary (-p, --base, --cfg).
D=${CF_DIR:-/data/local/tmp}
B=$D/.cf_esp
[ "$(id -u)" = 0 ] || { echo "need root"; exit 1; }
[ -f "$0" ] || { echo "save this file to $D and run it from there"; exit 1; }
sed '1,/^#__PAYLOAD__$/d' "$0" | base64 -d > "$B" || { echo "extract failed"; exit 1; }
chmod 755 "$B"
exec "$B" "$@"
#__PAYLOAD__
HDR
base64 "$BIN" | tr -d '\r' >> "$OUT"
chmod 755 "$OUT"
echo "ok -> $OUT ($(wc -c < "$OUT") bytes)"
