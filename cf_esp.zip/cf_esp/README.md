CounterFlame external ESP (root, read-only).
1. Termux: `sh build_termux.sh <android ver>` -> cf_esp.sh (single file).
2. MT Manager: run cf_esp.sh as root, game already in a match. INS button top-left = menu.
After a game patch: re-dump (Il2CppDumper) and `python3 tools/gen_offsets.py dump.cs script.json src/offsets.h`, rebuild.
Host core test: tests/test_core.cpp. Unverified on device: overlay_sf.cpp, build_termux.sh, field semantics (see game.cpp).

**GitHub**: push the folder to a repo -> Actions -> build -> download artifact cf_esp_a<your android ver>.sh (12/13/14).
