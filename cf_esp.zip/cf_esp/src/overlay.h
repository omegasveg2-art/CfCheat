// Android root overlay: SurfaceFlinger layer + EGL/GLES3 + ImGui, touch via /dev/input (evdev).
#pragma once

class Overlay {
public:
    bool init();                       // creates the layer; false if SurfaceFlinger/EGL refused
    bool begin_frame(float& W, float& H);   // logical (rotated) screen size; ImGui frame started
    void end_frame();
    void set_grab(bool on);            // true: swallow touches (menu open)
    void shutdown();
};
