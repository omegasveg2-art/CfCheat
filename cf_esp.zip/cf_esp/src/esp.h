#pragma once
#include "game.h"
#include "imgui.h"
#include <string>

struct Config {
    bool esp = true, box = true, cornerBox = false, health = true, hpText = true, name = true, dist = true, snap = false;
    bool teamCheck = true, radar = true, crosshair = false;
    float maxDist = 150.f, radarSize = 180.f, radarRange = 40.f;
    float fovScale = 1.f;          // multiplies camera fovY, tune if boxes drift when moving the view
    float headY = 1.8f, crouchY = 1.35f;   // box height in world units (standing / crouching)
    float boxAspect = 0.42f;
    float enemy[4] = {1.f, 0.25f, 0.2f, 1.f}, team[4] = {0.25f, 0.8f, 0.3f, 1.f};
};

bool config_save(const Config& c, const std::string& path);
bool config_load(Config& c, const std::string& path);

extern float g_W, g_H;   // logical screen size in px (set by main each frame)

struct UiState { bool menuOpen = false; bool wantUnload = false; };

// draws ESP into the foreground drawlist for the (W,H) logical screen
void esp_draw(const Config& c, const Snapshot& s, float W, float H);
// menu + floating toggle button; returns when done
void ui_draw(Config& c, UiState& ui, const Snapshot& s, const char* status, const std::string& cfgPath);
