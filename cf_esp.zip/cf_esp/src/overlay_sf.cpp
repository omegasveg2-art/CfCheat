// NOT built/tested by the author: needs AOSP headers (see build_termux.sh) matching the device Android version.
// -DAOSP_VER=12|13|14 selects the Transaction::setLayerStack signature.
#include "overlay.h"
#include "esp.h"
#include "imgui.h"
#include "backends/imgui_impl_opengl3.h"

#include <atomic>
#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <dirent.h>
#include <fcntl.h>
#include <linux/input.h>
#include <poll.h>
#include <string>
#include <sys/ioctl.h>
#include <thread>
#include <unistd.h>
#include <vector>

#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <android/native_window.h>
#include <binder/ProcessState.h>
#include <gui/Surface.h>
#include <gui/SurfaceComposerClient.h>
#include <gui/SurfaceControl.h>

#ifndef AOSP_VER
#define AOSP_VER 13
#endif

using namespace android;

namespace {
sp<SurfaceComposerClient> g_client;
sp<SurfaceControl> g_sc;
sp<Surface> g_surf;
EGLDisplay g_dpy = EGL_NO_DISPLAY;
EGLSurface g_egl = EGL_NO_SURFACE;
EGLContext g_ctx = EGL_NO_CONTEXT;
int g_S = 0;                                   // square surface edge = max(w,h)
std::atomic<int> g_w{1080}, g_h{2400}, g_rot{1};   // physical size, SurfaceOrientation (0..3)
std::atomic<bool> g_run{false}, g_grab{false};
std::atomic<float> g_tx{0}, g_ty{0};
std::atomic<bool> g_down{false};
std::thread g_touchThr, g_dispThr;

std::string sh(const char* cmd) {
    std::string out;
    if (FILE* f = popen(cmd, "r")) { char b[256]; while (fgets(b, sizeof b, f)) out += b; pclose(f); }
    return out;
}

void poll_display() {
    int w = 0, h = 0;
    std::string s = sh("wm size 2>/dev/null");              // "Physical size: 1080x2400" (+ optional Override size)
    size_t k = s.rfind("size:");
    if (k != std::string::npos) sscanf(s.c_str() + k + 5, " %dx%d", &w, &h);
    if (w > 0 && h > 0) { g_w = std::min(w, h); g_h = std::max(w, h); }
    s = sh("dumpsys input 2>/dev/null | grep -m1 -o 'SurfaceOrientation: [0-9]'");
    int r;
    if (sscanf(s.c_str(), "SurfaceOrientation: %d", &r) == 1) g_rot = r;
}

// ------------------------------------------------------------ touch (evdev)
struct Dev { int fd; int minx, maxx, miny, maxy; };
std::vector<Dev> g_devs;

bool bit(const unsigned long* a, int b) { return a[b / (8 * sizeof(long))] & (1ul << (b % (8 * sizeof(long)))); }

void open_touch() {
    DIR* d = opendir("/dev/input");
    if (!d) return;
    while (dirent* e = readdir(d)) {
        if (strncmp(e->d_name, "event", 5)) continue;
        std::string p = std::string("/dev/input/") + e->d_name;
        int fd = open(p.c_str(), O_RDONLY | O_NONBLOCK);
        if (fd < 0) continue;
        unsigned long abs[(ABS_MAX + 1) / (8 * sizeof(long)) + 1] = {0};
        unsigned long prop[(INPUT_PROP_MAX + 1) / (8 * sizeof(long)) + 1] = {0};
        ioctl(fd, EVIOCGBIT(EV_ABS, sizeof abs), abs);
        ioctl(fd, EVIOCGPROP(sizeof prop), prop);
        if (!bit(abs, ABS_MT_POSITION_X) || !bit(abs, ABS_MT_POSITION_Y) || !bit(prop, INPUT_PROP_DIRECT)) { close(fd); continue; }
        input_absinfo ax{}, ay{};
        ioctl(fd, EVIOCGABS(ABS_MT_POSITION_X), &ax);
        ioctl(fd, EVIOCGABS(ABS_MT_POSITION_Y), &ay);
        g_devs.push_back({fd, ax.minimum, ax.maximum, ay.minimum, ay.maximum});
    }
    closedir(d);
}

void touch_loop() {
    std::vector<pollfd> pf;
    for (auto& d : g_devs) pf.push_back({d.fd, POLLIN, 0});
    std::vector<int> rawx(g_devs.size(), 0), rawy(g_devs.size(), 0), slot(g_devs.size(), 0);
    std::vector<bool> grabbed(g_devs.size(), false);
    while (g_run) {
        bool want = g_grab;
        for (size_t i = 0; i < g_devs.size(); i++)
            if (grabbed[i] != want) { ioctl(g_devs[i].fd, EVIOCGRAB, want ? 1 : 0); grabbed[i] = want; }
        if (poll(pf.data(), (nfds_t)pf.size(), 50) <= 0) continue;
        for (size_t i = 0; i < g_devs.size(); i++) {
            if (!(pf[i].revents & POLLIN)) continue;
            input_event ev[64];
            ssize_t n;
            while ((n = read(g_devs[i].fd, ev, sizeof ev)) > 0) {
                for (size_t k = 0; k < (size_t)n / sizeof(input_event); k++) {
                    auto& e = ev[k];
                    if (e.type == EV_ABS) {
                        if (e.code == ABS_MT_SLOT) slot[i] = e.value;
                        else if (slot[i] == 0) {                       // first finger only
                            if (e.code == ABS_MT_POSITION_X) rawx[i] = e.value;
                            else if (e.code == ABS_MT_POSITION_Y) rawy[i] = e.value;
                            else if (e.code == ABS_MT_TRACKING_ID) g_down = e.value >= 0;
                        }
                    } else if (e.type == EV_SYN && e.code == SYN_REPORT) {
                        const Dev& d = g_devs[i];
                        float nx = (rawx[i] - d.minx) / (float)std::max(1, d.maxx - d.minx);
                        float ny = (rawy[i] - d.miny) / (float)std::max(1, d.maxy - d.miny);
                        float Wp = (float)g_w, Hp = (float)g_h, px = nx * Wp, py = ny * Hp, lx, ly;
                        switch (g_rot.load()) {
                            case 1:  lx = py;      ly = Wp - px; break;
                            case 2:  lx = Wp - px; ly = Hp - py; break;
                            case 3:  lx = Hp - py; ly = px;      break;
                            default: lx = px;      ly = py;
                        }
                        g_tx = lx; g_ty = ly;
                    }
                }
            }
        }
    }
    for (size_t i = 0; i < g_devs.size(); i++) { if (grabbed[i]) ioctl(g_devs[i].fd, EVIOCGRAB, 0); close(g_devs[i].fd); }
}
}  // namespace

bool Overlay::init() {
    poll_display();
    g_S = std::max(g_w.load(), g_h.load());
    ProcessState::self()->startThreadPool();
    g_client = new SurfaceComposerClient();
    if (g_client->initCheck() != NO_ERROR) { fprintf(stderr, "SurfaceComposerClient initCheck failed\n"); return false; }
    g_sc = g_client->createSurface(String8("cf_overlay"), g_S, g_S, PIXEL_FORMAT_RGBA_8888, 0);
    if (!g_sc || !g_sc->isValid()) { fprintf(stderr, "createSurface failed\n"); return false; }
    {
        SurfaceComposerClient::Transaction t;
        t.setLayer(g_sc, 0x7FFFFFFF);
#if AOSP_VER >= 13
        t.setLayerStack(g_sc, ui::LayerStack::fromValue(0));
#else
        t.setLayerStack(g_sc, 0);
#endif
        t.show(g_sc);
        t.apply();
    }
    g_surf = g_sc->getSurface();
    ANativeWindow* win = g_surf.get();

    g_dpy = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (!eglInitialize(g_dpy, nullptr, nullptr)) return false;
    const EGLint ca[] = {EGL_SURFACE_TYPE, EGL_WINDOW_BIT, EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT, EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8,
                         EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8, EGL_NONE};
    EGLConfig cfg; EGLint nc = 0;
    if (!eglChooseConfig(g_dpy, ca, &cfg, 1, &nc) || !nc) { fprintf(stderr, "eglChooseConfig failed\n"); return false; }
    const EGLint xa[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
    g_ctx = eglCreateContext(g_dpy, cfg, EGL_NO_CONTEXT, xa);
    g_egl = eglCreateWindowSurface(g_dpy, cfg, win, nullptr);
    if (g_ctx == EGL_NO_CONTEXT || g_egl == EGL_NO_SURFACE || !eglMakeCurrent(g_dpy, g_egl, g_egl, g_ctx)) { fprintf(stderr, "egl setup failed\n"); return false; }
    eglSwapInterval(g_dpy, 1);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    ImGui::StyleColorsDark();
    float sc = std::max(1.f, (float)std::min(g_w.load(), g_h.load()) / 540.f);
    ImGui::GetStyle().ScaleAllSizes(sc);
    io.FontGlobalScale = sc;
    ImGui_ImplOpenGL3_Init("#version 300 es");

    open_touch();
    g_run = true;
    g_touchThr = std::thread(touch_loop);
    g_dispThr = std::thread([] { while (g_run) { for (int i = 0; i < 20 && g_run; i++) std::this_thread::sleep_for(std::chrono::milliseconds(100)); if (g_run) poll_display(); } });
    return true;
}

bool Overlay::begin_frame(float& W, float& H) {
    bool land = g_rot == 1 || g_rot == 3;
    W = (float)(land ? g_h.load() : g_w.load());
    H = (float)(land ? g_w.load() : g_h.load());
    g_W = W; g_H = H;
    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2((float)g_S, (float)g_S);      // full square surface, origin top-left == screen top-left
    static auto last = std::chrono::steady_clock::now();
    auto nowt = std::chrono::steady_clock::now();
    io.DeltaTime = std::max(1e-4f, std::chrono::duration<float>(nowt - last).count());
    last = nowt;
    io.AddMousePosEvent(g_tx, g_ty);
    io.AddMouseButtonEvent(0, g_down);
    ImGui_ImplOpenGL3_NewFrame();
    ImGui::NewFrame();
    return true;
}

void Overlay::end_frame() {
    ImGui::Render();
    glViewport(0, 0, g_S, g_S);
    glClearColor(0, 0, 0, 0);
    glClear(GL_COLOR_BUFFER_BIT);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    eglSwapBuffers(g_dpy, g_egl);
}

void Overlay::set_grab(bool on) { g_grab = on; }

void Overlay::shutdown() {
    g_run = false;
    if (g_touchThr.joinable()) g_touchThr.join();
    if (g_dispThr.joinable()) g_dispThr.join();
    ImGui_ImplOpenGL3_Shutdown();
    ImGui::DestroyContext();
    if (g_dpy != EGL_NO_DISPLAY) {
        eglMakeCurrent(g_dpy, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (g_egl != EGL_NO_SURFACE) eglDestroySurface(g_dpy, g_egl);
        if (g_ctx != EGL_NO_CONTEXT) eglDestroyContext(g_dpy, g_ctx);
        eglTerminate(g_dpy);
    }
    g_surf.clear();
    if (g_sc) { SurfaceComposerClient::Transaction t; t.hide(g_sc); t.apply(); g_sc->clear(); }
    g_sc.clear(); g_client.clear();
}
