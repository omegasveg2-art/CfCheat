#include "esp.h"
#include <cstdio>
#include <cstring>
#include <fstream>
#include <sstream>

// ---------------------------------------------------------------- config (flat JSON)
struct Item { const char* k; int type; void* p; int n; };   // 0 bool, 1 float, 2 float[n]
static std::vector<Item> items(Config& c) {
    return {{"esp", 0, &c.esp, 1}, {"box", 0, &c.box, 1}, {"cornerBox", 0, &c.cornerBox, 1}, {"health", 0, &c.health, 1},
            {"hpText", 0, &c.hpText, 1}, {"name", 0, &c.name, 1}, {"dist", 0, &c.dist, 1}, {"snap", 0, &c.snap, 1},
            {"teamCheck", 0, &c.teamCheck, 1}, {"radar", 0, &c.radar, 1}, {"crosshair", 0, &c.crosshair, 1},
            {"maxDist", 1, &c.maxDist, 1}, {"radarSize", 1, &c.radarSize, 1}, {"radarRange", 1, &c.radarRange, 1},
            {"fovScale", 1, &c.fovScale, 1}, {"headY", 1, &c.headY, 1}, {"crouchY", 1, &c.crouchY, 1}, {"boxAspect", 1, &c.boxAspect, 1},
            {"enemy", 2, c.enemy, 4}, {"team", 2, c.team, 4}};
}

bool config_save(const Config& cc, const std::string& path) {
    Config& c = const_cast<Config&>(cc);
    std::ofstream f(path);
    if (!f) return false;
    f << "{\n";
    auto v = items(c);
    for (size_t i = 0; i < v.size(); i++) {
        f << "  \"" << v[i].k << "\": ";
        if (v[i].type == 0) f << (*(bool*)v[i].p ? "true" : "false");
        else if (v[i].type == 1) f << *(float*)v[i].p;
        else { f << "["; for (int j = 0; j < v[i].n; j++) f << (j ? ", " : "") << ((float*)v[i].p)[j]; f << "]"; }
        f << (i + 1 < v.size() ? ",\n" : "\n");
    }
    f << "}\n";
    return true;
}

bool config_load(Config& c, const std::string& path) {
    std::ifstream f(path);
    if (!f) return false;
    std::stringstream ss; ss << f.rdbuf();
    std::string s = ss.str();
    for (auto& it : items(c)) {
        size_t k = s.find(std::string("\"") + it.k + "\"");
        if (k == std::string::npos) continue;
        k = s.find(':', k);
        if (k == std::string::npos) continue;
        const char* p = s.c_str() + k + 1;
        while (*p == ' ') p++;
        if (it.type == 0) *(bool*)it.p = strncmp(p, "true", 4) == 0;
        else if (it.type == 1) *(float*)it.p = strtof(p, nullptr);
        else if (*p == '[') { p++; for (int j = 0; j < it.n; j++) { char* e; ((float*)it.p)[j] = strtof(p, &e); p = e; while (*p == ',' || *p == ' ') p++; } }
    }
    return true;
}

// ---------------------------------------------------------------- drawing
static ImU32 col(const float* c, float a = 1.f) { return ImGui::ColorConvertFloat4ToU32(ImVec4(c[0], c[1], c[2], c[3] * a)); }

static void corner_box(ImDrawList* d, ImVec2 a, ImVec2 b, ImU32 c, float th) {
    float lx = (b.x - a.x) * 0.25f, ly = (b.y - a.y) * 0.25f;
    d->AddLine(a, {a.x + lx, a.y}, c, th); d->AddLine(a, {a.x, a.y + ly}, c, th);
    d->AddLine({b.x, a.y}, {b.x - lx, a.y}, c, th); d->AddLine({b.x, a.y}, {b.x, a.y + ly}, c, th);
    d->AddLine({a.x, b.y}, {a.x + lx, b.y}, c, th); d->AddLine({a.x, b.y}, {a.x, b.y - ly}, c, th);
    d->AddLine(b, {b.x - lx, b.y}, c, th); d->AddLine(b, {b.x, b.y - ly}, c, th);
}

void esp_draw(const Config& c, const Snapshot& s, float W, float H) {
    ImDrawList* d = ImGui::GetBackgroundDrawList();
    if (c.crosshair) { d->AddCircle({W * .5f, H * .5f}, 3.f, IM_COL32(255, 255, 255, 200), 12, 1.5f); }
    if (!s.valid) return;
    Cam cam = s.cam; cam.fovY *= c.fovScale;
    float th = H / 540.f;                                   // line scale ~ resolution

    if (c.esp) for (auto& p : s.players) {
        if (p.local || p.dead) continue;
        bool mate = s.haveLocal && s.localTeam >= 1 && s.localTeam <= 2 && p.team == s.localTeam;
        if (mate && c.teamCheck) continue;
        float dist = len(p.pos - cam.pos);
        if (dist > c.maxDist) continue;
        float h = p.crouch ? c.crouchY : c.headY;
        float fx, fy, hx, hy;
        if (!w2s(cam, p.pos, W, H, fx, fy) || !w2s(cam, p.pos + Vec3{0, h, 0}, W, H, hx, hy)) continue;
        float bh = fy - hy; if (bh < 2.f) continue;
        float bw = bh * c.boxAspect;
        float cx = (fx + hx) * 0.5f;
        ImVec2 a{cx - bw * .5f, hy}, b{cx + bw * .5f, fy};
        ImU32 cc = col(mate ? c.team : c.enemy);
        if (c.box) {
            if (c.cornerBox) corner_box(d, a, b, cc, 1.5f * th);
            else { d->AddRect({a.x - 1, a.y - 1}, {b.x + 1, b.y + 1}, IM_COL32(0, 0, 0, 160), 0, 0, 3.f * th); d->AddRect(a, b, cc, 0, 0, 1.5f * th); }
        }
        if (c.health) {
            float f = p.hp < 0 ? 0 : (p.hp > 100 ? 1 : p.hp / 100.f);
            float x = a.x - 5.f * th;
            d->AddRectFilled({x - 1, a.y - 1}, {x + 2.5f * th + 1, b.y + 1}, IM_COL32(0, 0, 0, 170));
            d->AddRectFilled({x, b.y - bh * f}, {x + 2.5f * th, b.y}, IM_COL32((int)(255 * (1 - f)), (int)(255 * f), 40, 255));
            if (c.hpText) { char t[8]; snprintf(t, sizeof t, "%d", p.hp); d->AddText({x - 14.f * th, b.y - bh * f - 5.f}, IM_COL32_WHITE, t); }
        }
        float ty = a.y - 14.f * th;
        if (c.name && p.name[0]) { ImVec2 ts = ImGui::CalcTextSize(p.name); d->AddText({cx - ts.x * .5f, ty}, IM_COL32_WHITE, p.name); }
        if (c.dist) { char t[16]; snprintf(t, sizeof t, "%dm", (int)dist); ImVec2 ts = ImGui::CalcTextSize(t); d->AddText({cx - ts.x * .5f, b.y + 2.f}, IM_COL32(230, 230, 230, 255), t); }
        if (c.snap) d->AddLine({W * .5f, H}, {cx, b.y}, cc, 1.f * th);
    }

    if (c.radar && c.esp) {
        float R = c.radarSize * .5f * th;
        ImVec2 o{W - R - 20.f, R + 20.f};
        d->AddCircleFilled(o, R, IM_COL32(0, 0, 0, 110), 48);
        d->AddCircle(o, R, IM_COL32(255, 255, 255, 120), 48);
        Vec3 f = norm({cam.fwd.x, 0, cam.fwd.z});
        Vec3 r{f.z, 0, -f.x};                              // right = up x fwd, flattened
        for (auto& p : s.players) {
            if (p.dead) continue;
            Vec3 dv = p.pos - cam.pos;
            float x = dot(dv, r) / c.radarRange * R, y = -dot(dv, f) / c.radarRange * R;
            if (p.local) { x = 0; y = 0; }
            float l = std::sqrt(x * x + y * y);
            if (l > R - 4) { x *= (R - 4) / l; y *= (R - 4) / l; }
            bool mate = s.haveLocal && p.team == s.localTeam;
            d->AddCircleFilled({o.x + x, o.y + y}, p.local ? 3.f * th : 2.5f * th, p.local ? IM_COL32_WHITE : col(mate ? c.team : c.enemy));
        }
    }
}

// ---------------------------------------------------------------- menu
float g_W = 2400, g_H = 1080;
void ui_draw(Config& c, UiState& ui, const Snapshot& s, const char* status, const std::string& cfgPath) {
    // floating toggle (top-left)
    ImGui::SetNextWindowPos({8, 8});
    ImGui::SetNextWindowBgAlpha(0.35f);
    ImGui::Begin("##tgl", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings);
    if (ImGui::Button(ui.menuOpen ? "  X  " : " INS ")) ui.menuOpen = !ui.menuOpen;
    ImGui::End();
    if (!ui.menuOpen) return;

    ImGui::SetNextWindowSize({g_W * 0.42f, g_H * 0.7f}, ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowPos({g_W * 0.08f, g_H * 0.15f}, ImGuiCond_FirstUseEver);
    ImGui::Begin("CF", &ui.menuOpen, ImGuiWindowFlags_NoSavedSettings);
    if (ImGui::BeginTabBar("t")) {
        if (ImGui::BeginTabItem("ESP")) {
            ImGui::Checkbox("enabled", &c.esp); ImGui::Checkbox("box", &c.box); ImGui::SameLine(); ImGui::Checkbox("corner", &c.cornerBox);
            ImGui::Checkbox("health", &c.health); ImGui::SameLine(); ImGui::Checkbox("hp text", &c.hpText);
            ImGui::Checkbox("name", &c.name); ImGui::SameLine(); ImGui::Checkbox("distance", &c.dist);
            ImGui::Checkbox("snaplines", &c.snap); ImGui::Checkbox("hide teammates", &c.teamCheck);
            ImGui::SliderFloat("max dist", &c.maxDist, 20.f, 400.f);
            ImGui::ColorEdit4("enemy", c.enemy, ImGuiColorEditFlags_NoInputs); ImGui::SameLine();
            ImGui::ColorEdit4("team", c.team, ImGuiColorEditFlags_NoInputs);
            ImGui::EndTabItem();
        }
        if (ImGui::BeginTabItem("AIMBOT")) { ImGui::TextWrapped("not implemented (external aim needs touch injection)."); ImGui::EndTabItem(); }
        if (ImGui::BeginTabItem("MISC")) {
            ImGui::Checkbox("radar", &c.radar); ImGui::SliderFloat("radar range", &c.radarRange, 10.f, 120.f); ImGui::SliderFloat("radar size", &c.radarSize, 100.f, 300.f);
            ImGui::Checkbox("crosshair dot", &c.crosshair);
            ImGui::SeparatorText("calibration");
            ImGui::SliderFloat("fov scale", &c.fovScale, 0.7f, 1.3f); ImGui::SliderFloat("box height", &c.headY, 1.2f, 2.5f);
            ImGui::SliderFloat("crouch height", &c.crouchY, 1.0f, 2.0f); ImGui::SliderFloat("box aspect", &c.boxAspect, 0.25f, 0.7f);
            ImGui::EndTabItem();
        }
        if (ImGui::BeginTabItem("CONFIG")) {
            if (ImGui::Button("save")) config_save(c, cfgPath);
            ImGui::SameLine(); if (ImGui::Button("load")) config_load(c, cfgPath);
            ImGui::SameLine(); if (ImGui::Button("unload")) ui.wantUnload = true;
            ImGui::Text("game: %s", status);
            ImGui::Text("players %d  life %s  cam fov %.1f", (int)s.players.size(), s.lifeOk ? "ok" : "no", s.cam.fovY);
            ImGui::TextDisabled("%s", cfgPath.c_str());
            ImGui::EndTabItem();
        }
        ImGui::EndTabBar();
    }
    ImGui::End();
}
