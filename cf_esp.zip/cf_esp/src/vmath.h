#pragma once
#include <cmath>

struct Vec3 { float x = 0, y = 0, z = 0; };
inline Vec3 operator-(Vec3 a, Vec3 b) { return {a.x - b.x, a.y - b.y, a.z - b.z}; }
inline Vec3 operator+(Vec3 a, Vec3 b) { return {a.x + b.x, a.y + b.y, a.z + b.z}; }
inline float dot(Vec3 a, Vec3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
inline Vec3 cross(Vec3 a, Vec3 b) { return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x}; }
inline float len(Vec3 a) { return std::sqrt(dot(a, a)); }
inline Vec3 norm(Vec3 a) { float l = len(a); return l > 1e-6f ? Vec3{a.x / l, a.y / l, a.z / l} : Vec3{}; }

struct Cam {
    Vec3 pos, fwd;
    float fovY = 60.f;   // vertical, degrees (Unity Camera.fieldOfView convention)
};

// Unity: left-handed, +Y up, forward +Z, right +X. Roll is ignored (FPS, up = world up).
// Returns false when the point is behind the camera.
inline bool w2s(const Cam& c, Vec3 p, float W, float H, float& sx, float& sy) {
    Vec3 f = norm(c.fwd);
    Vec3 r = norm(cross({0, 1, 0}, f));        // left-handed: right = up x forward
    Vec3 u = cross(f, r);
    Vec3 d = p - c.pos;
    float z = dot(d, f);
    if (z < 0.05f) return false;
    float t = std::tan(c.fovY * 0.5f * 3.14159265f / 180.f);
    float aspect = W / H;
    sx = W * 0.5f + (dot(d, r) / (z * t * aspect)) * W * 0.5f;
    sy = H * 0.5f - (dot(d, u) / (z * t)) * H * 0.5f;
    return true;
}
