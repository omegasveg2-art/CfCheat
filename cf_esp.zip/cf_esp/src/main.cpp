// usage (root): ./cf_esp [-p <pkg substring, default counterflame>] [--base 0x<libil2cpp base>] [--cfg <path>]
// external read-only: no injection, nothing written into the game process.
#include "esp.h"
#include "overlay.h"
#include <chrono>
#include <csignal>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <thread>

static volatile sig_atomic_t g_stop = 0;
static void on_sig(int) { g_stop = 1; }

int main(int argc, char** argv) {
    std::string pkg = "counterflame", cfgPath = "/data/local/tmp/cf_esp.json";
    uint64_t baseOverride = 0;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-p") && i + 1 < argc) pkg = argv[++i];
        else if (!strcmp(argv[i], "--base") && i + 1 < argc) baseOverride = strtoull(argv[++i], nullptr, 16);
        else if (!strcmp(argv[i], "--cfg") && i + 1 < argc) cfgPath = argv[++i];
    }
    if (getuid() != 0) { fprintf(stderr, "needs root\n"); return 1; }
    signal(SIGINT, on_sig); signal(SIGTERM, on_sig);

    Config cfg; config_load(cfg, cfgPath);
    UiState ui;
    Overlay ov;
    if (!ov.init()) { fprintf(stderr, "overlay init failed\n"); return 2; }
    printf("overlay up, waiting for game '%s'\n", pkg.c_str());

    Proc proc;
    Snapshot snap;
    Game* game = nullptr;
    const char* status = "waiting for game";
    auto lastTry = std::chrono::steady_clock::now() - std::chrono::seconds(10);

    while (!g_stop && !ui.wantUnload) {
        if (game && !proc.alive()) { delete game; game = nullptr; proc.detach(); snap = Snapshot(); status = "game closed"; }
        if (!game && std::chrono::steady_clock::now() - lastTry > std::chrono::seconds(2)) {
            lastTry = std::chrono::steady_clock::now();
            int pid = Proc::find_pid(pkg);
            if (pid) {
                proc.attach(pid);
                uint64_t base = baseOverride ? baseOverride : proc.module_base("libil2cpp.so");
                if (base) { game = new Game(proc, base); printf("attached pid %d il2cpp base %llx\n", pid, (unsigned long long)base); }
                else { proc.detach(); status = "libil2cpp.so not mapped (use --base)"; }
            }
        }
        if (game) { game->update(snap); status = game->status(); }

        float W, H;
        ov.begin_frame(W, H);
        esp_draw(cfg, snap, W, H);
        ui_draw(cfg, ui, snap, status, cfgPath);
        ov.set_grab(ui.menuOpen);
        ov.end_frame();
        if (!game) std::this_thread::sleep_for(std::chrono::milliseconds(8));
    }
    delete game;
    ov.shutdown();
    return 0;
}
